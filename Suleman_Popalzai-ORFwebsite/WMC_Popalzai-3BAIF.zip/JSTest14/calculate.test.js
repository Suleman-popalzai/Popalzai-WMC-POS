import { describe, it, expect } from 'vitest';
// calculate.test.js
import { calculate } from './calculate';

describe('calculate function', () => {
  it('should return 6 for 4 + 2', () => {
    expect(calculate(4, 2, 'add')).toBe(6);
  });

  it('should return 2 for 4 - 2', () => {
    expect(calculate(4, 2, 'subtract')).toBe(2);
  });

  it('should return 8 for 4 * 2', () => {
    expect(calculate(4, 2, 'multiply')).toBe(8);
  });

  it('should return 2 for 4 / 2', () => {
    expect(calculate(4, 2, 'divide')).toBe(2);
  });

  it('should return null for non-numeric inputs', () => {
    expect(calculate('4', 2, 'add')).toBe(null);
  });

  it('should return null for invalid operations', () => {
    expect(calculate(4, 2, 'modulus')).toBe(null);
  });
});

