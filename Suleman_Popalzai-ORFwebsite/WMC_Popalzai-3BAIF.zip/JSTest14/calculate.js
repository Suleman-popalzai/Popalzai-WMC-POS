// calculate.js
export function calculate(a, b, operation) {
  if (typeof a !== 'number' || typeof b !== 'number') return null;

  switch (operation) {
    case 'add':
      return a + b;
    case 'subtract':
      return a - b;
    case 'multiply':
      return a * b;
    case 'divide':
      return b !== 0 ? a / b : null;
    default:
      return null;
  }
}
